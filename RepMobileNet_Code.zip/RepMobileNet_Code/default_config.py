import os
from yacs.config import CfgNode as CN


_C = CN()

_C.TAG = ''
_C.PRE_TRAINED = False
_C.PRE_TRAINED_WEIGHT_TYPE = 'mbv2_pre_trained'
_C.PRE_TRAINED_WEIGHT_NAME = 'mobilenet_v2.pth'

_C.SEEDS = 0
_C.CHECKPOINT_SAVE_FREQ = 10

# -----------------------------------------------------------------------------
# Directory settings
# -----------------------------------------------------------------------------
_C.DIR = CN()

_C.DIR.OUTPUT_DIR = 'outputs/'


# -----------------------------------------------------------------------------
# Model settings
# -----------------------------------------------------------------------------
_C.MODEL = CN()

_C.MODEL.ARCHITECTURE = 'RepMobileNet'
_C.MODEL.LINK = True
_C.MODEL.PIN_LINK = False
_C.MODEL.PIN_LINK_WEIGHT = []
_C.MODEL.NUM_CLASSES = 1000
_C.MODEL.EXPAND_RATIO = 6
_C.MODEL.ALPHA = 1.0
_C.MODEL.NO_LINEAR = 'relu6'
_C.MODEL.MODEL_NAME = 'V1'
_C.MODEL.BLOCK_SETTING = []
_C.MODEL.LABEL_SMOOTHING = 0.1


# -----------------------------------------------------------------------------
# Device settings
# -----------------------------------------------------------------------------
_C.DEVICE = "cpu"
_C.DISTRIBUTED_DEVICE_LIST = []


# -----------------------------------------------------------------------------
# Data settings
# -----------------------------------------------------------------------------
_C.DATA = CN()
_C.DATA.DATASET = 'Imagenet'
_C.DATA.IMG_SIZE = 224
_C.DATA.BATCH_SIZE = 128
_C.DATA.PIN_MEMORY = True
_C.DATA.NUM_WORKERS = 0


# -----------------------------------------------------------------------------
# Training settings
# -----------------------------------------------------------------------------
_C.TRAIN = CN()

_C.TRAIN.LR = 0.05
_C.TRAIN.WEIGHT_DECAY = 5e-4

_C.TRAIN.WARMUP_LR = 0.0
_C.TRAIN.MIN_LR = 0.0

_C.TRAIN.START_EPOCH = 0
_C.TRAIN.EPOCHS = 240
_C.TRAIN.WARMUP_EPOCHS = 5

_C.TRAIN.LABEL_SMOOTHING = 0.0
# CheckPoint
_C.TRAIN.USE_CHECKPOINT = False
_C.TRAIN.CHECKPOINT_DIR = ''


# -----------------------------------------------------------------------------
# LR scheduler
# -----------------------------------------------------------------------------
_C.TRAIN.LR_SCHEDULER = CN()

# Set the type of LR Scheduler
_C.TRAIN.LR_SCHEDULER.TYPE = 'CosineAnnealingLR'

_C.TRAIN.LR_SCHEDULER.Gamma = 0.1
_C.TRAIN.LR_SCHEDULER.LAST_EPOCH = -1
# Using StepLRScheduler
_C.TRAIN.LR_SCHEDULER.STEP_SIZE = 30
# Using MultiStepLR
_C.TRAIN.LR_SCHEDULER.MILESTONES = [20, 40, 60, 80, 100]


# -----------------------------------------------------------------------------
# Optimizer
# -----------------------------------------------------------------------------
# Optimizer
_C.TRAIN.OPTIMIZER = CN()
_C.TRAIN.OPTIMIZER.NAME = 'sgd'
# Optimizer Epsilon
_C.TRAIN.OPTIMIZER.EPS = 1e-8
# Optimizer Betas
_C.TRAIN.OPTIMIZER.BETAS = (0.9, 0.999)
# SGD momentum
_C.TRAIN.OPTIMIZER.MOMENTUM = 0.9



