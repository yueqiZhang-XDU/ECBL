import os
import sys
import time
import logging
import shutil
import random
import warnings
import argparse
import torch
import numpy as np
from torchstat import stat
from torchsummary import summary
from thop import profile
from thop import clever_format

from default_config import _C as cfg
from utils import setup_logger
from torch.utils.tensorboard import SummaryWriter
from model.repmobilenet_a import Repmobilenet_A
from model.repmobilenet_b import Repmobilenet_B
from utils import build_datatransform, bulid_dataloader, build_optimizer, build_lr_scheduler, build_warm_up_scheduler, CheckPointer
from utils import load_pre_trained_weight
from do_function import do_train, do_validate


def train(cfg, args):

    logger = logging.getLogger('{}.{}_trainer'.format(cfg.TAG, cfg.MODEL.ARCHITECTURE))
    logger.info("Start training ...")
    if cfg.MODEL.ARCHITECTURE == 'A':
        print('constructing RepMobileNet-A')
        model = Repmobilenet_A(input_size=cfg.DATA.IMG_SIZE, channel_multi=cfg.MODEL.ALPHA, num_class=cfg.MODEL.NUM_CLASSES, nolinear_type=cfg.MODEL.NO_LINEAR, block_setting=cfg.MODEL.BLOCK_SETTING)
    elif cfg.MODEL.ARCHITECTURE == 'B':
        print('constructing RepMobileNet-B')
        model = Repmobilenet_B(input_size=cfg.DATA.IMG_SIZE, num_class=cfg.MODEL.NUM_CLASSES, input_channel_multi=cfg.MODEL.ALPHA, block_setting=cfg.MODEL.BLOCK_SETTING)
    else:
        raise NotImplementedError("Only support RepMobileNet A and B structure Now")

    device = torch.device(cfg.DEVICE) if torch.cuda.is_available() else 'cpu'

    # Random seeds
    if cfg.SEEDS is not None:
        random.seed(cfg.SEEDS)
        torch.manual_seed(cfg.SEEDS)
        np.random.seed(cfg.SEEDS)
        torch.cuda.manual_seed(cfg.SEEDS)

    # Load Datasets
    datasets = build_datatransform(args)
    train_dataloader, val_dataloader = bulid_dataloader(datasets, cfg)
    logger.info('Number of dataset: train({}), validate({})'.format(len(datasets['train']), len(datasets['val'])))
    logger.info('Iter of dataloader: train_iter({}), val_iter({})'.format(len(train_dataloader), len(val_dataloader)))
    # Define Trainer
    optimizer = build_optimizer(model, cfg)

    # LR scheduler
    lr_scheduler = build_lr_scheduler(optimizer, cfg, len(train_dataloader))
    warm_up_scheduler = build_warm_up_scheduler(optimizer, cfg, len(train_dataloader))
    # checkpoint container
    checkpointer = CheckPointer(model, optimizer, lr_scheduler, args.checkpoint_save_path, True, logger)
    logger.info('Training environment has been built')

    model.to(device)

    if cfg.PRE_TRAINED:
        load_pre_trained_weight(model, cfg, args.pre_trained_weight_dir)

    if args.load_checkpoint is not None:
        logger.info('Load the checkpoint')
        checkpoint_dir = os.path.join(args.load_checkpoint)
        if os.path.isfile(checkpoint_dir):
            checkpointer.load(f=checkpoint_dir, use_latest=False)
        else:
            raise NotImplementedError("The checkpoint file is not exist")

    if args.use_tensorboard:
        writer = SummaryWriter(log_dir=args.tensorboard_save_path, comment=cfg.MODEL.ARCHITECTURE)
        writer.add_graph(model, (torch.randn([1, 3, cfg.DATA.IMG_SIZE, cfg.DATA.IMG_SIZE])).to(device))
    else:
        writer = None

    logger.info('***************************************************** Begin the Training Process *****************************************************')
    model = do_train(cfg, args, model, train_dataloader, val_dataloader, optimizer, lr_scheduler, warm_up_scheduler, checkpointer, logger, device, writer)

    if args.use_tensorboard:
        writer.close()

    logger.info('***************************************************** Training Process Finished *****************************************************')
    logger.info(model)


def main():
    parser = argparse.ArgumentParser(description='Train RepMobileNet for ImageNet Classification With Pytorch')
    parser.add_argument('--dataset_root', type=str, help='Set the Absolute Path of the Dataset')
    parser.add_argument('--config_file', type=str, help='Set the Relative Path of the config file')
    parser.add_argument('--load_checkpoint', type=str, default=None, help='Set the Relative Path of checkpoint to continue train')
    parser.add_argument('--use_tensorboard', type=bool, default=False, help='Choose to using the Tensorboard')

    args = parser.parse_args()

    num_gpus = int(os.environ["WORLD_SIZE"]) if "WORLD_SIZE" in os.environ else 1
    args.num_gpus = num_gpus if torch.cuda.is_available() else 1
    args.device = cfg.DEVICE if torch.cuda.is_available() else 1

    cfg.merge_from_file(args.config_file)
    cfg.freeze()

    # create the directory of the record file
    my_path = os.path.dirname(__file__) + '/'
    args.pretrained_path = os.path.join(my_path, 'pretrained')
    args.logging_save_path = os.path.join(my_path, cfg.DIR.OUTPUT_DIR, cfg.TAG)
    if not os.path.exists(args.logging_save_path):
        os.mkdir(args.logging_save_path)

    args.checkpoint_save_path = os.path.join(my_path, cfg.DIR.OUTPUT_DIR, cfg.TAG, 'checkpoint')
    if not os.path.exists(args.checkpoint_save_path):
        os.mkdir(args.checkpoint_save_path)

    args.tensorboard_save_path = os.path.join(my_path, cfg.DIR.OUTPUT_DIR, cfg.TAG, 'tensorboard')
    if not os.path.exists(args.tensorboard_save_path):
        os.mkdir(args.tensorboard_save_path)

    if cfg.PRE_TRAINED:
        args.pre_trained_weight_dir = os.path.join(my_path, 'pretrained/', cfg.PRE_TRAINED_WEIGHT_NAME)

    logger_name = cfg.DIR.OUTPUT_DIR + "_" + cfg.TAG
    logger = setup_logger(name=cfg.TAG, distributed_rank=0, save_dir=args.logging_save_path)
    logger.info("Using {} GPUs".format(num_gpus))
    logger.info(args)

    logger.info("Loaded configuration file {}".format(args.config_file))
    with open(args.config_file, "r") as cf:
        config_str = "\n" + cf.read()
        logger.info(config_str)
    logger.info("Running with config:\n{}".format(cfg))

    train(cfg, args)


if __name__ == '__main__':
    main()

