import torch.nn as nn
from model.utils import conv_1x1_bn, conv_3x3_bn, ExpandConv, CompressConv
from model.convert import get_shortcut_params, get_equivalent_params, get_equivalent_pad_params, get_shortcut_bn_params, fuse_poinwise_conv


class ResBottleneckBlock_B(nn.Module):
    def __init__(self, in_chn, out_chn, stride, expand_ratio, pw2_relu=False, tail_dw=False, tail_relu=False):
        super(ResBottleneckBlock_B, self).__init__()

        self.in_chn = int(in_chn)
        self.out_chn = int(out_chn)
        self.expand_ratio = expand_ratio
        self.hidden_chn = int(self.in_chn * expand_ratio)

        assert stride in [1, 2]
        self.stride = stride

        self.nolinear = nn.ReLU(inplace=True)
        self.use_res_connect = (self.stride == 1 and self.in_chn == self.out_chn)

        self.pw2_relu = pw2_relu
        self.tail_dw = tail_dw
        self.tail_relu = tail_relu

        if expand_ratio > 1:
            self.pw1 = conv_1x1_bn(in_chn=self.in_chn, out_chn=self.hidden_chn)

        self.dw = conv_3x3_bn(in_chn=self.hidden_chn, out_chn=self.hidden_chn, stride=self.stride, groups=self.hidden_chn)
        self.dw1x1 = conv_1x1_bn(in_chn=self.hidden_chn, out_chn=self.hidden_chn, stride=self.stride, groups=self.hidden_chn)

        if self.stride == 1:
            self.dw_identity = nn.BatchNorm2d(num_features=self.hidden_chn)

        if self.use_res_connect and expand_ratio > 1:
            self.expand_branch = ExpandConv(in_chn=self.in_chn, expand_ratio=expand_ratio)
            self.compress_branch = CompressConv(out_chn=self.out_chn, expand_ratio=expand_ratio)

        self.pw2 = conv_1x1_bn(in_chn=self.hidden_chn, out_chn=self.out_chn)

        if tail_dw:
            self.tail_dw3x3 = conv_3x3_bn(in_chn=self.out_chn, out_chn=self.out_chn, stride=1, groups=self.out_chn)
            self.tail_dw1x1 = conv_1x1_bn(in_chn=self.out_chn, out_chn=self.out_chn, stride=1, groups=self.out_chn)
            self.tail_identity = nn.BatchNorm2d(num_features=self.out_chn)




    def forward(self, inputs):

        if self.expand_ratio == 1:
            if self.stride == 1:
                result = self.dw(inputs) + self.dw1x1(inputs) + self.dw_identity(inputs)
            else:
                result = self.dw(inputs) + self.dw1x1(inputs)
            result = self.nolinear(result)
            result = self.pw2(result)
        else:
            if self.use_res_connect:
                result = self.pw1(inputs) + self.expand_branch(inputs)
                result = self.nolinear(result)
                result = self.dw(result) + self.dw1x1(result) + self.dw_identity(result)
                result = self.nolinear(result)
                result = self.pw2(result) + self.compress_branch(result)
            else:
                result = self.pw1(inputs)
                result = self.nolinear(result)
                result = self.dw(result) + self.dw1x1(result)
                result = self.nolinear(result)
                result = self.pw2(result)

        if self.pw2_relu:
            result = self.nolinear(result)

        if self.tail_dw:
            result = self.tail_dw3x3(result) + self.tail_dw1x1(result) + self.tail_identity(result)

        if self.tail_relu:
            result = self.nolinear(result)

        return result


    def block_multi_branch_merge(self):
        single_branch = nn.Sequential()
        if self.expand_ratio == 1:
            if self.stride == 1:
                dw_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.hidden_chn, kernel_size=(3, 3),
                                    stride=self.stride, padding=1, bias=True, groups=self.hidden_chn)
                dw_equivalent_kernel,    dw_equivalent_bias = get_equivalent_params(self.dw)
                dw1x1_equivalent_kernel, dw1x1_equivalent_bias = get_equivalent_pad_params(self.dw1x1)
                dw_id_equivalent_kernel, dw_id_equivalent_bias = get_shortcut_bn_params(self.dw_identity, device=self.dw[0].weight.device)
                dw_fuse.weight.data = dw_equivalent_kernel + dw1x1_equivalent_kernel + dw_id_equivalent_kernel
                dw_fuse.bias.data = dw_equivalent_bias + dw1x1_equivalent_bias + dw_id_equivalent_bias
            else:  # Merge the Depthwise Conv + 1x1branch
                dw_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.hidden_chn, kernel_size=(3, 3),
                                    stride=self.stride, padding=1, bias=True, groups=self.hidden_chn)
                dw_equivalent_kernel, dw_equivalent_bias = get_equivalent_params(self.dw)
                dw1x1_equivalent_kernel, dw1x1_equivalent_bias = get_equivalent_pad_params(self.dw1x1)
                dw_fuse.weight.data = dw_equivalent_kernel + dw1x1_equivalent_kernel
                dw_fuse.bias.data = dw_equivalent_bias + dw1x1_equivalent_bias
            single_branch.add_module('dw', dw_fuse)  # equivalent dw layer
            single_branch.add_module('ReLU_dw', self.nolinear)  # no linearity layer

            # Merge the PointWise Conv 2
            pw2_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.out_chn, kernel_size=(1, 1),
                                 stride=(1, 1), padding=0, bias=True, groups=1)
            pw2_equivalent_kernel, pw2_equivalent_bias = get_equivalent_params(self.pw2)
            pw2_fuse.weight.data = pw2_equivalent_kernel
            pw2_fuse.bias.data = pw2_equivalent_bias

            single_branch.add_module('pw2', pw2_fuse)      # equivalent pw2 layer

        else:  # 含有PW1模块
            if self.use_res_connect:
                # pw1 + expand_ratio
                pw1_expand_fuse = nn.Conv2d(in_channels=self.in_chn, out_channels=self.hidden_chn, kernel_size=(1, 1),
                                            stride=(1, 1), padding=0, bias=True, groups=1)
                pw1_equivalent_kernel, pw1_equivalent_bias = get_equivalent_params(self.pw1)
                expand_branch_kernel, expand_branch_bias = self.expand_branch.get_equivalent_params()
                pw1_expand_fuse.weight.data = pw1_equivalent_kernel + expand_branch_kernel
                pw1_expand_fuse.bias.data = pw1_equivalent_bias + expand_branch_bias
                single_branch.add_module('pw1', pw1_expand_fuse)
                # no linearity layer
                single_branch.add_module('ReLU_pw1', self.nolinear)

                #  dw3x3 + dw1x1 + id(shortcut)
                dw_id_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.hidden_chn, kernel_size=(3, 3),
                                       stride=self.stride, padding=1, bias=True, groups=self.hidden_chn)
                dw_equivalent_kernel, dw_equivalent_bias = get_equivalent_params(self.dw)
                dw1x1_equivalent_kernel, dw1x1_equivalent_bias = get_equivalent_pad_params(self.dw1x1)
                dw_id_equivalent_kernel, dw_id_equivalent_bias = get_shortcut_bn_params(self.dw_identity, device=self.dw[0].weight.device)

                dw_id_fuse.weight.data = dw_equivalent_kernel + dw1x1_equivalent_kernel + dw_id_equivalent_kernel
                dw_id_fuse.bias.data = dw_equivalent_bias + dw1x1_equivalent_bias + dw_id_equivalent_bias
                single_branch.add_module('dw', dw_id_fuse)

                # no linearity layer
                single_branch.add_module('ReLU_dw', self.nolinear)

                # pw2 + compress branch
                pw2_compress_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.out_chn, kernel_size=(1, 1),
                                              stride=(1, 1), padding=0, bias=True, groups=1)
                pw2_equivalent_kernel, pw2_equivalent_bias = get_equivalent_params(self.pw2)
                compress_branch_kernel, compress_branch_bias = self.compress_branch.get_equivalent_params()
                pw2_compress_fuse.weight.data = pw2_equivalent_kernel + compress_branch_kernel
                pw2_compress_fuse.bias.data = pw2_equivalent_bias + compress_branch_bias
                single_branch.add_module('pw2', pw2_compress_fuse)

            else:
                # Fuse pw1 + bn
                pw1_fuse = nn.Conv2d(in_channels=self.in_chn, out_channels=self.hidden_chn, kernel_size=(1, 1),
                                     stride=(1, 1), padding=0, bias=True, groups=1)
                pw1_equivalent_kernel, pw1_equivalent_bias = get_equivalent_params(self.pw1)
                pw1_fuse.weight.data = pw1_equivalent_kernel
                pw1_fuse.bias.data = pw1_equivalent_bias
                single_branch.add_module('pw1', pw1_fuse)
                # no linearity layer
                single_branch.add_module('ReLU_pw1', self.nolinear)

                # fuse dw + bn
                dw_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.hidden_chn, kernel_size=(3, 3),
                                    stride=self.stride, padding=1, bias=True, groups=self.hidden_chn)
                dw_equivalent_kernel, dw_equivalent_bias = get_equivalent_params(self.dw)
                dw1x1_equivalent_kernel, dw1x1_equivalent_bias = get_equivalent_pad_params(self.dw1x1)

                dw_fuse.weight.data = dw_equivalent_kernel + dw1x1_equivalent_kernel
                dw_fuse.bias.data = dw_equivalent_bias + dw1x1_equivalent_bias
                single_branch.add_module('dw', dw_fuse)
                # no linearity
                single_branch.add_module('ReLU_dw', self.nolinear)

                # fuse pw2 + bn
                pw2_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.out_chn, kernel_size=(1, 1),
                                     stride=(1, 1), padding=0, bias=True, groups=1)
                pw2_equivalent_kernel, pw2_equivalent_bias = get_equivalent_params(self.pw2)
                pw2_fuse.weight.data = pw2_equivalent_kernel
                pw2_fuse.bias.data = pw2_equivalent_bias
                single_branch.add_module('pw2', pw2_fuse)

        if self.pw2_relu:
            single_branch.add_module('ReLU_pw2', self.nolinear)

        if self.tail_dw:
            tail_fuse = nn.Conv2d(in_channels=self.out_chn, out_channels=self.out_chn, kernel_size=(3, 3),
                                  stride=(1, 1), padding=1, bias=True, groups=self.out_chn)
            tail_dw3x3_equivalent_kernel, tail_dw3x3_equivalent_bias = get_equivalent_params(self.tail_dw3x3)
            tail_dw1x1_equivalent_kernel, tail_dw1x1_equivalent_bias = get_equivalent_pad_params(self.tail_dw1x1)
            tail_id_equivalent_kernel, tail_id_equivalent_bias = get_shortcut_bn_params(self.tail_identity, device=self.tail_identity.weight.device)

            tail_fuse.weight.data = tail_dw3x3_equivalent_kernel + tail_dw1x1_equivalent_kernel + tail_id_equivalent_kernel
            tail_fuse.bias.data = tail_dw3x3_equivalent_bias + tail_dw1x1_equivalent_bias + tail_id_equivalent_bias
            single_branch.add_module('tail_dw', tail_fuse)

        if self.tail_relu:
            single_branch.add_module('ReLU_tail_dw', self.nolinear)

        return single_branch


