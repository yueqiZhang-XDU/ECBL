import torch.nn as nn
from model.utils import conv_1x1_bn, conv_3x3_bn, ExpandConv, CompressConv
from model.convert import get_shortcut_params, get_equivalent_params, get_equivalent_pad_params, get_shortcut_bn_params, fuse_poinwise_conv


class ResBottleneckBlock_A(nn.Module):
    def __init__(self, in_chn, out_chn, stride, expand_ratio, k=4):
        super(ResBottleneckBlock_A, self).__init__()
        self.stride = stride
        assert stride in [1, 2]

        hidden_chn = int(in_chn * expand_ratio)
        self.in_chn = in_chn
        self.hidden_chn = hidden_chn
        self.out_chn = out_chn
        self.expand_ratio = expand_ratio
        self.use_res_connect = (stride == 1 and in_chn == out_chn)
        if expand_ratio > 1:
            self.pw1 = conv_1x1_bn(in_chn=in_chn, out_chn=hidden_chn)

        self.dw_k1 = conv_3x3_bn(in_chn=hidden_chn, out_chn=hidden_chn, stride=stride, groups=hidden_chn)
        self.dw_k2 = conv_3x3_bn(in_chn=hidden_chn, out_chn=hidden_chn, stride=stride, groups=hidden_chn)
        self.dw_k3 = conv_3x3_bn(in_chn=hidden_chn, out_chn=hidden_chn, stride=stride, groups=hidden_chn)
        self.dw_k4 = conv_3x3_bn(in_chn=hidden_chn, out_chn=hidden_chn, stride=stride, groups=hidden_chn)

        self.dw1x1 = conv_1x1_bn(in_chn=hidden_chn, out_chn=hidden_chn, stride=stride, groups=hidden_chn)

        self.pw2 = conv_1x1_bn(in_chn=hidden_chn, out_chn=out_chn)
        self.nolinear = nn.ReLU(inplace=True)
        if self.use_res_connect and expand_ratio > 1:
            self.expand_branch = ExpandConv(in_chn=in_chn, expand_ratio=expand_ratio)
            self.compress_branch = CompressConv(out_chn=out_chn, expand_ratio=expand_ratio)
            self.dw_bn = nn.BatchNorm2d(num_features=hidden_chn)

    def forward(self, inputs):

        if self.expand_ratio == 1:
            result = self.dw1x1(inputs) + (self.dw_k1(inputs) + self.dw_k2(inputs) + self.dw_k3(inputs) + self.dw_k4(inputs))
            result = self.nolinear(result)
            result = self.pw2(result)
            return result
        else:
            if self.use_res_connect:
                result = self.pw1(inputs) + self.expand_branch(inputs)
                result = self.nolinear(result)
                result = self.dw1x1(result) + self.dw_bn(result) + (self.dw_k1(result) + self.dw_k2(result) + self.dw_k3(result) + self.dw_k4(result))
                result = self.nolinear(result)
                result = self.pw2(result) + self.compress_branch(result)
                return result

            else:
                result = self.pw1(inputs)
                result = self.nolinear(result)
                result = self.dw1x1(result) + (self.dw_k1(result) + self.dw_k2(result) + self.dw_k3(result) + self.dw_k4(result))
                result = self.nolinear(result)
                result = self.pw2(result)
                return result

    def block_multi_branch_merge(self):
        single_branch = nn.Sequential()
        if self.expand_ratio == 1:
            # Fuse dw + bn + dw1x1
            dw_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.hidden_chn, kernel_size=(3, 3),
                                stride=self.stride, padding=1, bias=True, groups=self.hidden_chn)

            dw_equivalent_kernel1, dw_equivalent_bias1 = get_equivalent_params(self.dw_k1)
            dw_equivalent_kernel2, dw_equivalent_bias2 = get_equivalent_params(self.dw_k2)
            dw_equivalent_kernel3, dw_equivalent_bias3 = get_equivalent_params(self.dw_k3)
            dw_equivalent_kernel4, dw_equivalent_bias4 = get_equivalent_params(self.dw_k4)

            dw1x1_equivalent_kernel, dw1x1_equivalent_bias = get_equivalent_pad_params(self.dw1x1)
            dw_fuse.weight.data = dw_equivalent_kernel1 + dw_equivalent_kernel2 + dw_equivalent_kernel3 + dw_equivalent_kernel4 + dw1x1_equivalent_kernel
            dw_fuse.bias.data = dw_equivalent_bias1 + dw_equivalent_bias2 + dw_equivalent_bias3 + dw_equivalent_bias4 + dw1x1_equivalent_bias
            single_branch.add_module('dw', dw_fuse)
            # no linearity layer
            single_branch.add_module('ReLU_dw', self.nolinear)
            # Fuse pw2 + bn
            pw2_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.out_chn, kernel_size=(1, 1),
                                 stride=(1, 1), padding=0, bias=True, groups=1)
            pw2_equivalent_kernel, pw2_equivalent_bias = get_equivalent_params(self.pw2)
            pw2_fuse.weight.data = pw2_equivalent_kernel
            pw2_fuse.bias.data = pw2_equivalent_bias
            single_branch.add_module('pw2', pw2_fuse)
        else:
            if self.use_res_connect:
                # fuse the expand_conv to pw1, shortcut to dw and the compress_conv to pw2
                # pw1 + expand_ratio
                pw1_expand_fuse = nn.Conv2d(in_channels=self.in_chn, out_channels=self.hidden_chn, kernel_size=(1, 1),
                                            stride=(1, 1), padding=0, bias=True, groups=1)
                pw1_equivalent_kernel, pw1_equivalent_bias = get_equivalent_params(self.pw1)
                expand_branch_kernel, expand_branch_bias = self.expand_branch.get_equivalent_params()
                pw1_expand_fuse.weight.data = pw1_equivalent_kernel + expand_branch_kernel
                pw1_expand_fuse.bias.data = pw1_equivalent_bias + expand_branch_bias
                single_branch.add_module('pw1', pw1_expand_fuse)
                # no linearity layer
                single_branch.add_module('ReLU_pw', self.nolinear)

                # dw + id(shortcut)
                dw_id_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.hidden_chn, kernel_size=(3, 3),
                                       stride=self.stride, padding=1, bias=True, groups=self.hidden_chn)
                dw_equivalent_kernel1, dw_equivalent_bias1 = get_equivalent_params(self.dw_k1)
                dw_equivalent_kernel2, dw_equivalent_bias2 = get_equivalent_params(self.dw_k2)
                dw_equivalent_kernel3, dw_equivalent_bias3 = get_equivalent_params(self.dw_k3)
                dw_equivalent_kernel4, dw_equivalent_bias4 = get_equivalent_params(self.dw_k4)
                dw1x1_equivalent_kernel, dw1x1_equivalent_bias = get_equivalent_pad_params(self.dw1x1)
                id_equivalent_kernel, id_equivalent_bias = get_shortcut_bn_params(self.dw_bn, device=self.dw_k1[0].weight.device)

                dw_id_fuse.weight.data = dw_equivalent_kernel1 + dw_equivalent_kernel2 + dw_equivalent_kernel3 + dw_equivalent_kernel4 + id_equivalent_kernel + dw1x1_equivalent_kernel
                dw_id_fuse.bias.data = dw_equivalent_bias1 + dw_equivalent_bias2 + dw_equivalent_bias3 + dw_equivalent_bias4 + id_equivalent_bias + dw1x1_equivalent_bias
                single_branch.add_module('dw', dw_id_fuse)
                # no linearity layer
                single_branch.add_module('ReLU_dw', self.nolinear)

                # pw2 + compress branch
                pw2_compress_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.out_chn, kernel_size=(1, 1),
                                              stride=(1, 1), padding=0, bias=True, groups=1)
                pw2_equivalent_kernel, pw2_equivalent_bias = get_equivalent_params(self.pw2)
                compress_branch_kernel, compress_branch_bias = self.compress_branch.get_equivalent_params()
                pw2_compress_fuse.weight.data = pw2_equivalent_kernel + compress_branch_kernel
                pw2_compress_fuse.bias.data = pw2_equivalent_bias + compress_branch_bias
                single_branch.add_module('pw2', pw2_compress_fuse)

            else:
                # Fuse pw1 + bn
                pw1_fuse = nn.Conv2d(in_channels=self.in_chn, out_channels=self.hidden_chn, kernel_size=(1, 1),
                                     stride=(1, 1), padding=0, bias=True, groups=1)
                pw1_equivalent_kernel, pw1_equivalent_bias = get_equivalent_params(self.pw1)
                pw1_fuse.weight.data = pw1_equivalent_kernel
                pw1_fuse.bias.data = pw1_equivalent_bias
                single_branch.add_module('pw1', pw1_fuse)
                # no linearity layer
                single_branch.add_module('ReLU_pw', self.nolinear)

                # fuse dw + bn
                dw_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.hidden_chn, kernel_size=(3, 3),
                                    stride=self.stride, padding=1, bias=True, groups=self.hidden_chn)
                dw_equivalent_kernel1, dw_equivalent_bias1 = get_equivalent_params(self.dw_k1)
                dw_equivalent_kernel2, dw_equivalent_bias2 = get_equivalent_params(self.dw_k2)
                dw_equivalent_kernel3, dw_equivalent_bias3 = get_equivalent_params(self.dw_k3)
                dw_equivalent_kernel4, dw_equivalent_bias4 = get_equivalent_params(self.dw_k4)

                dw1x1_equivalent_kernel, dw1x1_equivalent_bias = get_equivalent_pad_params(self.dw1x1)
                dw_fuse.weight.data = dw_equivalent_kernel1 + dw_equivalent_kernel2 + dw_equivalent_kernel3 + dw_equivalent_kernel4 + dw1x1_equivalent_kernel
                dw_fuse.bias.data = dw_equivalent_bias1 + dw_equivalent_bias2 + dw_equivalent_bias3 + dw_equivalent_bias4 + dw1x1_equivalent_bias
                single_branch.add_module('dw', dw_fuse)
                # no linearity
                single_branch.add_module('ReLU_dw', self.nolinear)

                # fuse pw2 + bn
                pw2_fuse = nn.Conv2d(in_channels=self.hidden_chn, out_channels=self.out_chn, kernel_size=(1, 1),
                                     stride=(1, 1), padding=0, bias=True, groups=1)
                pw2_equivalent_kernel, pw2_equivalent_bias = get_equivalent_params(self.pw2)
                pw2_fuse.weight.data = pw2_equivalent_kernel
                pw2_fuse.bias.data = pw2_equivalent_bias
                single_branch.add_module('pw2', pw2_fuse)

        return single_branch