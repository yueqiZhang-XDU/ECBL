import torch
import torch.nn as nn

"""
    定义了三个函数用于对于对网络模型进行分支合并与重构
        get_shortcut_params:    将残差连接等效为一层卷积核为3*3的卷积映射,获得等效卷积层的权值
        get_equivalent_params： 将卷积层与BN层的参数进行合并，获得等效卷积层的卷积核权值与偏置权值
        get_equivalent_pad_params： 获得网络权值，
.        fuse_poinwise_conv：    针对MLP的合并，将两个相连的PW conv等效合并为一个层pointwise conv
"""


def get_shortcut_params(in_chn, device):
    identity_kernel = torch.zeros([in_chn, 1, 3, 3])
    identity_bias = torch.zeros([in_chn])
    for i in range(in_chn):
        identity_kernel[i][0][1][1] = 1
    identity_kernel.to(device)
    identity_bias.to(device)
    return identity_kernel, identity_bias


def get_shortcut_bn_params(shortcut_bn_branch, device):
    if isinstance(shortcut_bn_branch, nn.BatchNorm2d):
        in_chn = shortcut_bn_branch.num_features
        identity_kernel = torch.zeros([in_chn, 1, 3, 3])
        for i in range(in_chn):
            identity_kernel[i][0][1][1] = 1
        identity_kernel.to(device)

        running_mean = shortcut_bn_branch.running_mean
        running_var = shortcut_bn_branch.running_var
        gamma = shortcut_bn_branch.weight
        beta = shortcut_bn_branch.bias
        eps = shortcut_bn_branch.eps
        std = (running_var + eps).sqrt()
        t = (gamma / std).reshape(-1, 1, 1, 1)

        equivalent_kernel = identity_kernel * t
        equivalent_bias = beta - running_mean * gamma / std
        return equivalent_kernel, equivalent_bias
    else:
        raise NotImplementedError(" Invalid type of the input merge branch ")


def get_equivalent_params(branch):
    if isinstance(branch[0], nn.Conv2d):
        if len(branch) > 1:
            if isinstance(branch[1], nn.BatchNorm2d):                   # conv + bn
                kernel = branch[0].weight
                running_mean = branch[1].running_mean
                running_var = branch[1].running_var
                gamma = branch[1].weight
                beta = branch[1].bias
                eps = branch[1].eps
                #
                std = (running_var + eps).sqrt()
                t = (gamma / std).reshape(-1, 1, 1, 1)
                equivalent_kernel = kernel * t
                equivalent_bias = beta - running_mean * gamma / std
                return equivalent_kernel, equivalent_bias
            else:
                raise NotImplementedError(" Can't get the equivalent kernel and bias from the branch ")
        else:                                                           # conv
            equivalent_kernel = branch[0].weight
            equivalent_bias = torch.zeros([branch[0].out_channels])
            return equivalent_kernel, equivalent_bias

    elif isinstance(branch[0], nn.BatchNorm2d):                         # bn
        in_chn = branch[0].num_features
        kernel = torch.zeros([in_chn, 1, 3, 3])
        for i in range(in_chn):
            kernel[i][0][1][1] = 1
        kernel.to(branch[0].weight.device)
        running_mean = branch[0].running_mean
        running_var = branch[0].running_var
        gamma = branch[0].weight
        beta = branch[0].bias
        eps = branch[0].eps

        std = (running_var + eps).sqrt()
        t = (gamma / std).reshape(-1, 1, 1, 1)
        equivalent_kernel = kernel * t
        equivalent_bias = beta - running_mean * gamma / std
        return equivalent_kernel, equivalent_bias

    else:
        raise NotImplementedError(" Can't get the equivalent kernel and bias from the branch ")


def get_equivalent_pad_params(branch):
    # 输入的branch必须是 1x1conv 分支
    if len(branch) == 1:  # no bn
        if isinstance(branch[0], nn.Conv2d):
            kernel1x1 = branch[0].weight
            equivalent_kernel = torch.nn.functional.pad(kernel1x1, [1, 1, 1, 1])
            equivalent_bias = torch.zeros([branch[0].out_channels])
            return equivalent_kernel, equivalent_bias
        else:
            raise NotImplementedError("The input structure is not support")

    elif isinstance(branch[1], nn.BatchNorm2d):  # conv + bn
        kernel1x1 = branch[0].weight
        kernel3x3 = torch.nn.functional.pad(kernel1x1, [1, 1, 1, 1])
        running_mean = branch[1].running_mean
        running_var = branch[1].running_var
        gamma = branch[1].weight
        beta = branch[1].bias
        eps = branch[1].eps
        #
        std = (running_var + eps).sqrt()
        t = (gamma / std).reshape(-1, 1, 1, 1)
        equivalent_kernel = kernel3x3 * t
        equivalent_bias = beta - running_mean * gamma / std
        return equivalent_kernel, equivalent_bias


def fuse_poinwise_conv(pointwise_conv1, pointwise_conv2):

    # 通过输入的pw得到合并后的权值信息
    in_chn = pointwise_conv1.in_channels
    out_chn = pointwise_conv2.out_channels
    # create the equivalent kernel
    equivalent_pw = nn.Conv2d(in_channels=in_chn, out_channels=out_chn, kernel_size=(1, 1), stride=(1, 1), padding=0, groups=1, bias=True)

    pw1_kernel = pointwise_conv1.weight
    pw1_bias = pointwise_conv1.bias
    pw2_kernel = pointwise_conv2.weight
    pw2_bias = pointwise_conv2.bias

    # get the equivalent kernel
    equivalent_kernel = torch.mm(pw2_kernel.squeeze(-1).squeeze(-1), pw1_kernel.squeeze(-1).squeeze(-1))
    equivalent_kernel = equivalent_kernel.unsqueeze(-1).unsqueeze(-1)

    # get the equivalent bias
    equivalent_bias = torch.mm(pw2_kernel.squeeze(-1).squeeze(-1), pw1_bias.unsqueeze(-1))
    equivalent_bias = equivalent_bias.squeeze(-1) + pw2_bias

    # set the kernel and bias of equivalent_pw
    equivalent_pw.weight.data = equivalent_kernel
    equivalent_pw.bias.data = equivalent_bias

    return equivalent_pw



if __name__ == '__main__':

    pdist = nn.PairwiseDistance(p=2)
    in_chn = 16
    out_chn = 16
    test_data = torch.randn([1, 16, 32, 32])

    test_branch1 = nn.Sequential(
        nn.Conv2d(in_channels=in_chn, out_channels=out_chn, kernel_size=(1, 1), stride=(1, 1), padding=0, groups=1, bias=False)
    )

    test_branch2 = nn.Sequential(
        nn.Conv2d(in_channels=in_chn, out_channels=out_chn, kernel_size=(1, 1), stride=(1, 1), padding=0, groups=1, bias=False),
        nn.BatchNorm2d(num_features=out_chn)
    )

    equivalent_branch = nn.Conv2d(in_channels=in_chn, out_channels=out_chn, kernel_size=(3, 3), stride=(1, 1), padding=1, groups=1, bias=True)
    equivalent_branch.eval()

    print('test the merge of the single 1x1conv')
    test_branch1.eval()
    target = test_branch1(test_data)
    equivalent_kernel, equivalent_bias = get_equivalent_pad_params(test_branch1)
    equivalent_branch.weight.data = equivalent_kernel
    equivalent_branch.bias.data = equivalent_bias
    output = equivalent_branch(test_data)
    result = pdist(target, output)
    print(2)

    test_branch2.eval()
    target = test_branch2(test_data)
    equivalent_kernel, equivalent_bias = get_equivalent_pad_params(test_branch2)
    equivalent_branch.weight.data = equivalent_kernel
    equivalent_branch.bias.data = equivalent_bias
    output = equivalent_branch(test_data)
    result = pdist(target, output)

    print(3)