import torch.nn as nn
from model.utils import make_divisible, conv_1x1_bn, conv_3x3_bn
from model.convert import get_equivalent_params, fuse_poinwise_conv
from BasicBlock.RepBottleneckBlock_B import ResBottleneckBlock_B
from BasicBlock.LinearBottleneck import InvertedResidual


class Repmobilenet_B(nn.Module):
    def __init__(self, input_size=224, num_class=1000, input_channel_multi=1.0, object_detection_mode=False, block_setting=None):
        super(Repmobilenet_B, self).__init__()
        self.block = ResBottleneckBlock_B  # Select the basic block to construct the RepMobileNet
        self.object_detection_mode = object_detection_mode  # Construct the classifier for image classification(False) or extra layer for object detection(True)
        self.mode = 'Multi-branch'

        assert input_size % 32 == 0
        self.input_channel = int(make_divisible(32 * input_channel_multi))
        self.last_channel = self.input_channel

        if block_setting == []:
            self.block_setting = [
                # block_num, in_chn, out_chn, stride, expand_ratio, block_channel_multi, pw2_relu, tail_dw, tail_relu
                [2,  32,  32, 2, 2,   1, False, True,  False],  # stage1  output_size：56 * 56 * 32
                [3,  32,  64, 2, 2,   1, False, True,  False],  # stage2  output_size：28 * 28 * 64
                [4,  64,  64, 2, 2,   1, False, True,  False],  # stage3  output_size：14 * 14 * 64
                [2,  64, 128, 1, 2,   1, True,  True,  True],  # stage4  output_size： 14 * 14 * 128
                [2, 128, 256, 2, 2,   1, True,  True,  True],  # stage5  output_size： 7 *  7 *  256
                [1, 256, 512, 1, 1,   2, True,  True,  True],  # stage5  output_size： 7 *  7 *  512
            ]
        else:
            self.block_setting = block_setting

        self.nolinear = nn.ReLU(inplace=True)

        # construct network.features
        self.stage_num = 0
        self.features = nn.Sequential()
        self.features.add_module('stage0', nn.Sequential(conv_3x3_bn(in_chn=3, out_chn=self.last_channel, stride=2), self.nolinear))  # output 112*112
        for block_num, in_chn, out_chn, stride, expand_ratio, block_channel_multi, pw2_relu, tail_dw, tail_relu in self.block_setting:
            self.stage_num = self.stage_num + 1
            self.features.add_module(f'stage{self.stage_num}', self._make_stage(self.block,
                                                                                block_num=block_num,
                                                                                in_chn=self.last_channel,
                                                                                out_chn=int(make_divisible(out_chn * block_channel_multi)),
                                                                                stride=stride,
                                                                                expand_ratio=expand_ratio,
                                                                                pw2_relu=pw2_relu,
                                                                                tail_dw=tail_dw,
                                                                                tail_relu=tail_relu,
                                                                                )
                                     )
            self.last_channel = int(make_divisible(out_chn * block_channel_multi))

        # construct classifier for Image Classification or Object Detection
        if object_detection_mode:
            self.extras = nn.ModuleList([
                InvertedResidual(1280, 512, 2, 0.2),
                InvertedResidual(512, 256, 2, 0.5),
                InvertedResidual(256, 256, 2, 0.5),
                InvertedResidual(256, 64, 2, 0.5)
            ])
        else:
            self.avg_pool = nn.AdaptiveAvgPool2d(output_size=1)
            # 输入为最后一层的通道数，输出为last channel

            self.classifier = nn.Sequential(
                nn.Linear(in_features=self.last_channel, out_features=num_class)
            )

        # Weight Init
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)


    def weight_pin_link(self, fixed_weight, device='cpu'):
        for index, layer_stage in enumerate(self.features):
            for sub_index, sub_block in enumerate(layer_stage):
                if isinstance(sub_block, self.block):
                    if sub_block.use_res_connect & (sub_block.expand_ratio > 1):
                        # 第一步 set weight
                        sub_block.expand_branch.pin_weight(fixed_weight)
                        # 第二步 link weight
                        sub_block.to(device)
                        expand_branch_weight = sub_block.expand_branch.get_weight()
                        self.features[index][sub_index].compress_branch.weight_link(expand_branch_weight, device)

    def forward(self, x):
        if self.object_detection_mode:  # got output features from different layers to SSD head for Object detection
            print('Object detection')
        else:  # Get the features to classifier for ImageClassification
            result = self.features(x)
            result = self.avg_pool(result)
            result = result.view(result.size(0), -1)  # change tensor shape: delete the H, W dimension, same as flatten operation
            result = self.classifier(result)
            return result

    def _make_stage(self, block, block_num, in_chn, out_chn, stride, expand_ratio, pw2_relu, tail_dw, tail_relu):

        layers = []
        layers.append(block(in_chn, out_chn, stride, expand_ratio, pw2_relu, tail_dw, tail_relu))
        while block_num - 1:
            layers.append(block(out_chn, out_chn, 1, expand_ratio, pw2_relu, tail_dw, tail_relu))
            block_num -= 1

        return nn.Sequential(*layers)

    def convert_to_single_branch(self):
        # this function is designed to convert train to inference
        single_branch_features = nn.Sequential()
        for stage_index, current_stage in enumerate(self.features):
            if stage_index == 0:  # conv_bn + ReLU
                if isinstance(current_stage[0], self.block):
                    for block_index, block in enumerate(current_stage):
                        equivalent_block = block.block_multi_branch_merge()
                        for layer_index, current_layers in enumerate(equivalent_block):
                            single_branch_features.append(current_layers)
                else:
                    equivalent_kernel, equivalent_bias = get_equivalent_params(current_stage[0])
                    equivalent_conv = nn.Conv2d(in_channels=3, out_channels=self.input_channel, kernel_size=(3, 3), stride=(2, 2), padding=1, groups=1, bias=True)
                    equivalent_conv.weight.data = equivalent_kernel
                    equivalent_conv.bias.data = equivalent_bias
                    single_branch_features.append(equivalent_conv)
                    single_branch_features.append(self.nolinear)

            else:  # 剩下的stage都是由basic block构成
                for block_index, block in enumerate(current_stage):
                    if isinstance(block, self.block):   # block
                        equivalent_block = block.block_multi_branch_merge()
                        for layer_index, current_layers in enumerate(equivalent_block):
                            single_branch_features.append(current_layers)

        self.features = single_branch_features
        print('convert the features of net to single branch structure')

    def fuse_pw_layers(self):
        next_layer = []
        skip_flag = 0
        fuse_pw_net = nn.Sequential()
        for layer_index, current_layer in enumerate(self.features):
            if skip_flag == 1:
                skip_flag = 0
                continue
            else:
                if layer_index == len(self.features)-1:
                    fuse_pw_net.append(current_layer)
                else:
                    next_layer = self.features[layer_index+1]
                    if isinstance(current_layer, nn.Conv2d) & isinstance(next_layer, nn.Conv2d):
                        if (current_layer.kernel_size == (1, 1)) & (next_layer.kernel_size == (1, 1)):
                            fuse_pw_conv = fuse_poinwise_conv(current_layer, next_layer)
                            fuse_pw_net.append(fuse_pw_conv)
                            skip_flag = 1
                        else:
                            fuse_pw_net.append(current_layer)
                    else:
                        fuse_pw_net.append(current_layer)
        self.features = fuse_pw_net
