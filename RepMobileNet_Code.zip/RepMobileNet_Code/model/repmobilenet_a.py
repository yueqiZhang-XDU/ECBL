import torch.nn as nn
from model.utils import make_divisible, conv_3x3_bn
from model.convert import get_equivalent_params, fuse_poinwise_conv
from BasicBlock.RepBottleneckBlock_A import ResBottleneckBlock_A
from BasicBlock.LinearBottleneck import InvertedResidual


def nolinear_select(nolinear_type):
    if nolinear_type == 'relu6':
        nolinear = nn.ReLU6(inplace=True)
    elif nolinear_type == 'relu':
        nolinear = nn.ReLU(inplace=True)
    else:
        raise NotImplementedError("Current network are not support")
    return nolinear


class Repmobilenet_A(nn.Module):

    def __init__(self, input_size=224, channel_multi=1.0, num_class=1000, object_detection_mode=False, nolinear_type='relu', block_setting=[]):
        super(Repmobilenet_A, self).__init__()

        self.block = ResBottleneckBlock_A
        self.object_detection_mode = object_detection_mode
        self.mode = 'Multi-branch'

        # Hyper-parameter
        self.chn_multi = channel_multi
        input_size = input_size
        assert input_size % 32 == 0

        # set channel number
        self.input_channel = int(make_divisible(32 * self.chn_multi))
        self.last_channel = int(make_divisible(1280 * max(1.0, self.chn_multi)))

        if block_setting == []:
            self.block_setting = [
                # block_num, in_chn, out_chn, stride, expand_ratio
                [1, 32, 16, 1, 1],   # 224 * 224
                [2, 16, 24, 2, 6],   # 112 * 112
                [3, 24, 32, 2, 6],   # 56  * 56
                [4, 32, 64, 2, 6],   # 28  * 28
                [3, 64, 96, 1, 6],   # 14  * 14
                [3, 96, 160, 2, 6],  # 7 * 7
                [1, 160, 320, 1, 6]
            ]
        else:
            self.block_setting = block_setting

        self.nolinear = nolinear_select(nolinear_type)
        self.block.nolinear = self.nolinear

        self.features = nn.Sequential()
        self.stage_num = 0
        self.features.add_module('stage0', nn.Sequential(conv_3x3_bn(in_chn=3, out_chn=self.input_channel, stride=2), self.nolinear))

        for block_num, in_chn, out_chn, stride, expand_ratio in self.block_setting:
            # block_num, in_chn, out_chn, stride, expand_ratio
            self.stage_num = self.stage_num + 1
            self.features.add_module(f'stage{self.stage_num}', self._make_stage(self.block,
                                                                                block_num=block_num,
                                                                                in_chn=int(make_divisible(in_chn*self.chn_multi)),
                                                                                out_chn=int(make_divisible(out_chn*self.chn_multi)),
                                                                                stride=stride,
                                                                                expand_ratio=expand_ratio
                                                                                )
                                     )
            self.out_channel = int(make_divisible(out_chn*self.chn_multi))
        self.features.add_module('last_stage', nn.Sequential(
            nn.Conv2d(in_channels=self.out_channel, out_channels=self.last_channel, kernel_size=(1, 1), stride=(1, 1), bias=False),
            nn.BatchNorm2d(num_features=self.last_channel),
            self.nolinear)
        )

        if object_detection_mode:
            self.extras = nn.ModuleList([
                InvertedResidual(1280, 512, 2, 0.2),
                InvertedResidual(512, 256, 2, 0.5),
                InvertedResidual(256, 256, 2, 0.5),
                InvertedResidual(256, 64, 2, 0.5)
            ])
        else:
            self.avg_pool = nn.AdaptiveAvgPool2d(output_size=1)

            self.classifier = nn.Sequential(
                nn.Linear(in_features=self.last_channel, out_features=num_class)
            )

        # Weight Init
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def _make_stage(self, block, block_num, in_chn, out_chn, stride, expand_ratio):

        layers = []
        layers.append(block(in_chn, out_chn, stride, expand_ratio))
        while block_num - 1:
            layers.append(block(out_chn, out_chn, 1, expand_ratio))
            block_num -= 1

        return nn.Sequential(*layers)

    def forward(self, x):
        if self.object_detection_mode:
            features = []
            if self.mode == 'Multi-branch':
                for i in range(6):
                    x = self.features[i](x)
                features.append(x)

                for i in range(6, len(self.features)):
                    x = self.features[i](x)
                features.append(x)

            elif self.mode == 'Single-Branch':
                for i in range(65):
                    x = self.features[i](x)
                features.append(x)

                for i in range(65, len(self.features)):
                    x = self.features[i](x)
                features.append(x)
            else:
                raise NotImplementedError("unknown model")

            for j in range(len(self.extras)):
                x = self.extras[j](x)
                features.append(x)

            return tuple(features)

        else:
            result = self.features(x)
            result = self.avg_pool(result)
            result = result.view(result.size(0), -1)  # change tensor shape: delete the H, W dimension, same as flatten operation
            result = self.classifier(result)
            return result

    def weight_pin_link(self, fixed_weight, device='cpu'):
        for index, layer_stage in enumerate(self.features):
            for sub_index, sub_block in enumerate(layer_stage):
                if isinstance(sub_block, self.block):
                    if sub_block.use_res_connect:
                        # 第一步 set weight
                        sub_block.expand_branch.pin_weight(fixed_weight)
                        # 第二步 link weight
                        sub_block.to(device)
                        expand_branch_weight = sub_block.expand_branch.get_weight()
                        self.features[index][sub_index].compress_branch.weight_link(expand_branch_weight, device)

    def link(self, device):
        for index, layer_stage in enumerate(self.features):
            for sub_index, sub_block in enumerate(layer_stage):
                if isinstance(sub_block, self.block):
                    if sub_block.use_res_connect:  # if the current block using res connection branch
                        expand_branch_weight = sub_block.expand_branch.get_weight()
                        self.features[index][sub_index].compress_branch.weight_link(expand_branch_weight, device)

    def convert_to_single_branch(self):
        # this function is designed to convert train to inference
        single_branch_features = nn.Sequential()

        for stage_index, current_stage in enumerate(self.features):
            if stage_index == 0:  # conv_bn + ReLU
                equivalent_kernel, equivalent_bias = get_equivalent_params(current_stage[0])
                equivalent_conv = nn.Conv2d(in_channels=3, out_channels=self.input_channel, kernel_size=(3, 3), stride=(2, 2), padding=1, groups=1, bias=True)
                equivalent_conv.weight.data = equivalent_kernel
                equivalent_conv.bias.data = equivalent_bias

                single_branch_features.append(equivalent_conv)
                single_branch_features.append(self.nolinear)

            elif stage_index == self.stage_num + 1:  # conv + bn + ReLU
                equivalent_kernel, equivalent_bias = get_equivalent_params(current_stage[:2])
                equivalent_conv = nn.Conv2d(in_channels=current_stage[0].in_channels,
                                            out_channels=current_stage[0].out_channels,
                                            kernel_size=current_stage[0].kernel_size,
                                            stride=current_stage[0].stride,
                                            bias=True
                                            )
                equivalent_conv.weight.data = equivalent_kernel
                equivalent_conv.bias.data = equivalent_bias

                single_branch_features.append(equivalent_conv)
                single_branch_features.append(self.nolinear)

            else:
                for block_index, block in enumerate(current_stage):
                    if isinstance(block, self.block):   # block
                        equivalent_block = block.block_multi_branch_merge()
                        for layer_index, current_layers in enumerate(equivalent_block):
                            single_branch_features.append(current_layers)
        self.mode = 'Single-Branch'
        self.features = single_branch_features

        # freeze the backbone
        for k, v in self.features.named_parameters():
            v.requires_grad = False

        print('convert the features of net to single branch structure')

    def fuse_pw_layers(self):
        next_layer = []
        skip_flag = 0
        fuse_pw_net = nn.Sequential()
        for layer_index, current_layer in enumerate(self.features):
            if skip_flag == 1:
                skip_flag = 0
                continue
            else:
                if layer_index == len(self.features)-1:
                    fuse_pw_net.append(current_layer)
                else:
                    next_layer = self.features[layer_index+1]
                    if isinstance(current_layer, nn.Conv2d) & isinstance(next_layer, nn.Conv2d):
                        fuse_pw_conv = fuse_poinwise_conv(current_layer, next_layer)
                        fuse_pw_net.append(fuse_pw_conv)
                        skip_flag = 1
                    else:
                        fuse_pw_net.append(current_layer)
        return fuse_pw_net







