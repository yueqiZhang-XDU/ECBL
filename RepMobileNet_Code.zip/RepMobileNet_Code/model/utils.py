import numpy as np
import torch
import torch.nn as nn


def make_divisible(x, divisible_by=8):
    return int(np.ceil(x * 1. / divisible_by) * divisible_by)


def conv_3x3_bn(in_chn, out_chn, stride=1, groups=1):
    return nn.Sequential(
        nn.Conv2d(in_channels=in_chn, out_channels=out_chn, kernel_size=(3, 3), stride=(stride, stride), padding=1, groups=groups, bias=False),
        nn.BatchNorm2d(num_features=out_chn)
    )


def conv_1x1_bn(in_chn, out_chn, stride=1, groups=1):
    return nn.Sequential(
        nn.Conv2d(in_channels=in_chn, out_channels=out_chn, kernel_size=(1, 1), stride=(stride, stride), padding=0, groups=groups, bias=False),
        nn.BatchNorm2d(num_features=out_chn)
    )


class ConvBNReLU(nn.Sequential):
    def __init__(self, in_planes, out_planes, kernel_size=3, stride=1, groups=1):
        padding = (kernel_size - 1) // 2
        super(ConvBNReLU, self).__init__(
            nn.Conv2d(in_channels=in_planes, out_channels=out_planes,
                      kernel_size=(kernel_size, kernel_size), stride=(stride, stride),
                      padding=padding, groups=groups, bias=False),
            nn.BatchNorm2d(out_planes),
            nn.ReLU6(inplace=True)
        )


def expand_branch(in_chn, out_chn, stride=1, groups=1):
    return nn.Sequential(
        nn.Conv2d(in_channels=in_chn, out_channels=out_chn, kernel_size=(1, 1), stride=(stride, stride), padding=0, groups=groups, bias=False)
    )


def compress_branch(in_chn, out_chn, stride=1, groups=1):
    return nn.Sequential(
        nn.Conv2d(in_channels=in_chn, out_channels=out_chn, kernel_size=(1, 1), stride=(stride, stride), padding=0, groups=groups, bias=False)
    )


class ExpandConv(nn.Module):
    def __init__(self, in_chn, expand_ratio):
        super(ExpandConv, self).__init__()
        self.in_chn = in_chn
        self.expand_chn = in_chn * expand_ratio
        self.expand_ratio = expand_ratio
        self.weight = []
        self.device = torch.cuda.current_device() if torch.cuda.is_available() else 'cpu'

        for i in range(expand_ratio):
            # exec('self.expand_branch{} = conv_1x1_bn(in_chn=in_chn, out_chn=in_chn, groups = in_chn)'.format(i))
            exec('self.expand_branch{} = expand_branch(in_chn=in_chn, out_chn=in_chn, groups = in_chn)'.format(i))

    def forward(self, inputs):
        result = []
        y = torch.tensor([]).to(self.device)
        for i in range(self.expand_ratio):
            exec('result.append(self.expand_branch{}(inputs))'.format(i))

        for branch_result in result:
            y = torch.cat((y, branch_result), 1)

        return y

    # get the weight of expand_branch(1-expand_ratio)
    def get_weight(self):
        self.weight = []
        for i in range(self.expand_ratio):
            exec('self.weight.append(self.expand_branch{}[0].weight)'.format(i))

        expand_weight = torch.tensor([]).to(self.device)
        for branch_weight in self.weight:
            expand_weight = torch.cat((expand_weight, branch_weight), 0)

        return expand_weight

    def get_equivalent_params(self):
        # 仅考虑conv的情况下
        self.weight = []
        for i in range(self.expand_ratio):
            exec('self.weight.append(self.expand_branch{}[0].weight)'.format(i))

        expand_weight = torch.tensor([])
        for branch_weight in self.weight:
            expand_weight = torch.cat((expand_weight, branch_weight), 0)

        equivalent_kernel = torch.zeros([self.expand_chn, self.in_chn, 1, 1])
        for i in range(self.expand_ratio):
            for j in range(self.in_chn):
                equivalent_kernel[self.in_chn * i + j][j][0][0] = expand_weight[self.in_chn * i + j][0][0][0]

        equivalent_bias = torch.zeros([self.expand_chn])

        return equivalent_kernel, equivalent_bias

    def pin_weight(self, fixed_weight=None):
        if fixed_weight is None:
            fixed_weight = [0.5, 1, 2, -2, -1, -0.5]
        for i in range(self.expand_ratio):
            fixed_factor = fixed_weight[i]
            link_fixed_weight = torch.ones([self.in_chn, 1, 1, 1]) * fixed_factor
            link_fixed_weight.to(self.device)
            exec('self.expand_branch{}[0].weight.data = link_fixed_weight'.format(i))

        for name, param in self.named_parameters():
            param.requires_grad = False


class CompressConv(nn.Module):
    def __init__(self, out_chn, expand_ratio):
        super(CompressConv, self).__init__()
        self.out_chn = out_chn
        self.expand_ratio = expand_ratio
        self.compress_chn = out_chn * expand_ratio
        self.compress_branch = compress_branch(in_chn=self.compress_chn, out_chn=out_chn, groups=1)

    def forward(self, inputs):
        return self.compress_branch(inputs)

    def weight_link(self, weight, device='cpu'):             # the size of input weight: [hidden_dim, 1, 1, 1]
        linked_weight = torch.zeros([self.out_chn, self.out_chn*self.expand_ratio, 1, 1]).to(device)
        for j in range(self.expand_ratio):
            for i in range(self.out_chn):
                linked_weight[i][j*self.out_chn+i][0][0] = torch.clamp(1 / weight[j*self.out_chn + i] / self.expand_ratio, min=-18, max=18)
        # linked_weight.requires_grad = False
        self.compress_branch[0].weight.data = linked_weight
        self.compress_branch[0].weight.requires_grad = False

    def get_equivalent_params(self):
        equivalent_kernel = self.compress_branch[0].weight
        equivalent_bias = torch.zeros([self.out_chn])

        return equivalent_kernel, equivalent_bias


def load_mbv2_pretrained_weight(net, weight_dir='./checkpoint/mobilenet_v2.pth'):
    
    block_index = 0
    mbv2_pretrained_weight = torch.load(weight_dir, map_location='cpu')

    for stage_index, current_stage in enumerate(net.features):
        if stage_index == 0:  # conv_bn + ReLU
            block_index = 0
            # print('The first stage')
            # conv2d
            net.features[stage_index][0][0].weight.data = mbv2_pretrained_weight['features.{}.0.weight'.format(block_index)]
            # bn
            set_bn_params(bn_layer=net.features[0][0][1], pretrained_weight=mbv2_pretrained_weight,
                          stage_index=stage_index, block_index=block_index, layer_index=1)

        elif stage_index == net.stage_num + 1:
            # print('the last stage')
            block_index = 18
            # conv
            net.features[stage_index][0].weight.data = mbv2_pretrained_weight['features.{}.0.weight'.format(block_index)]
            # bn
            net.features[stage_index][1].weight.data = mbv2_pretrained_weight['features.{}.1.weight'.format(block_index)]
            net.features[stage_index][1].bias.data = mbv2_pretrained_weight['features.{}.1.bias'.format(block_index)]
            net.features[stage_index][1].running_mean.data = mbv2_pretrained_weight['features.{}.1.running_mean'.format(block_index)]
            net.features[stage_index][1].running_var.data = mbv2_pretrained_weight['features.{}.1.running_var'.format(block_index)]
            net.features[stage_index][1].num_batches_tracked.data = mbv2_pretrained_weight['features.{}.1.num_batches_tracked'.format(block_index)]

        else:
            for repbottleneck_index, block in enumerate(current_stage):
                block_index += 1
                if block.expand_ratio == 1:
                    # dw
                    net.features[stage_index][repbottleneck_index].dw[0].weight.data = \
                        mbv2_pretrained_weight['features.{}.conv.0.0.weight'.format(block_index)]
                    set_bn_params(bn_layer=net.features[stage_index][repbottleneck_index].dw[1], pretrained_weight=mbv2_pretrained_weight,
                                  stage_index=stage_index, block_index=block_index, layer_index=0)
                    # pw2
                    net.features[stage_index][repbottleneck_index].pw2[0].weight.data = \
                        mbv2_pretrained_weight['features.{}.conv.1.weight'.format(block_index)]
                    set_bn_params(bn_layer=net.features[stage_index][repbottleneck_index].pw2[1], pretrained_weight=mbv2_pretrained_weight,
                                  stage_index=stage_index, block_index=block_index, layer_index=2, is_pw2=True)
                else:
                    # pw1
                    net.features[stage_index][repbottleneck_index].pw1[0].weight.data = \
                        mbv2_pretrained_weight['features.{}.conv.0.0.weight'.format(block_index)]
                    set_bn_params(bn_layer=net.features[stage_index][repbottleneck_index].pw1[1], pretrained_weight=mbv2_pretrained_weight,
                                  stage_index=stage_index, block_index=block_index, layer_index=0)

                    # dw
                    net.features[stage_index][repbottleneck_index].dw[0].weight.data = \
                        mbv2_pretrained_weight['features.{}.conv.1.0.weight'.format(block_index)]
                    set_bn_params(bn_layer=net.features[stage_index][repbottleneck_index].dw[1], pretrained_weight=mbv2_pretrained_weight,
                                  stage_index=stage_index, block_index=block_index, layer_index=1)

                    # pw2
                    net.features[stage_index][repbottleneck_index].pw2[0].weight.data = \
                        mbv2_pretrained_weight['features.{}.conv.2.weight'.format(block_index)]
                    set_bn_params(bn_layer=net.features[stage_index][repbottleneck_index].pw2[1], pretrained_weight=mbv2_pretrained_weight,
                                  stage_index=stage_index, block_index=block_index, layer_index=3, is_pw2=True)

    print('load all the mobilenetV2 pretrained weight to Rep-MobileNet successful')


def set_bn_params(bn_layer, pretrained_weight, stage_index, block_index, layer_index, is_pw2=False):

    if stage_index == 0:
        bn_layer.weight.data = pretrained_weight['features.{}.{}.weight'.format(block_index, layer_index)]
        bn_layer.bias.data = pretrained_weight['features.{}.{}.bias'.format(block_index, layer_index)]
        bn_layer.running_mean.data = pretrained_weight['features.{}.{}.running_mean'.format(block_index, layer_index)]
        bn_layer.running_var.data = pretrained_weight['features.{}.{}.running_var'.format(block_index, layer_index)]
        bn_layer.num_batches_tracked.data = pretrained_weight['features.{}.{}.num_batches_tracked'.format(block_index, layer_index)]
        print('set the stage{} block{} bn weight'.format(stage_index, block_index, layer_index))
    elif is_pw2:
        bn_layer.weight.data = pretrained_weight['features.{}.conv.{}.weight'.format(block_index, layer_index)]
        bn_layer.bias.data = pretrained_weight['features.{}.conv.{}.bias'.format(block_index, layer_index)]
        bn_layer.running_mean.data = pretrained_weight['features.{}.conv.{}.running_mean'.format(block_index, layer_index)]
        bn_layer.running_var.data = pretrained_weight['features.{}.conv.{}.running_var'.format(block_index, layer_index)]
        bn_layer.num_batches_tracked.data = pretrained_weight['features.{}.conv.{}.num_batches_tracked'.format(block_index, layer_index)]
    else:
        bn_layer.weight.data = pretrained_weight['features.{}.conv.{}.1.weight'.format(block_index, layer_index)]
        bn_layer.bias.data = pretrained_weight['features.{}.conv.{}.1.bias'.format(block_index, layer_index)]
        bn_layer.running_mean.data = pretrained_weight['features.{}.conv.{}.1.running_mean'.format(block_index, layer_index)]
        bn_layer.running_var.data = pretrained_weight['features.{}.conv.{}.1.running_var'.format(block_index, layer_index)]
        bn_layer.num_batches_tracked.data = pretrained_weight['features.{}.conv.{}.1.num_batches_tracked'.format(block_index, layer_index)]
