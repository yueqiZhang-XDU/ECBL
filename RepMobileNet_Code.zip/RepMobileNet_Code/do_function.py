import time
import sys
from tqdm import tqdm
import torch
import torch.nn as nn
from timm.loss import LabelSmoothingCrossEntropy
from utils import AverageMeter, accuracy


def do_validate(cfg, args, model, val_dataloader, criterion, device):

    batch_time = AverageMeter('Time', ':6.3f')
    losses = AverageMeter('Loss', ':.4e')
    top1 = AverageMeter('Acc@1', ':6.3f')
    top5 = AverageMeter('Acc@5', ':6.3f')

    model.eval()
    with torch.no_grad():
        val_bar = tqdm(iterable=val_dataloader, desc='Validate:', file=sys.stdout)  # desc 前缀
        begin_time = time.time()

        for i, data in enumerate(val_bar):
            images, target = data
            images = images.to(device)
            target = target.to(device)

            # val prop
            output = model(images)
            loss = criterion(output, target)

            # measure accuracy and record loss
            acc1, acc5 = accuracy(output, target, topk=(1, 5))
            losses.update(loss.item(), images.size(0))
            top1.update(acc1[0], images.size(0))
            top5.update(acc5[0], images.size(0))

            # measure elapsed time
            batch_time.update(time.time() - begin_time)
            begin_time = time.time()

            val_bar.set_description(
                'Validate Process: [{}/{}] '.format(i+1, len(val_dataloader)))
            val_bar.set_postfix({'Batch prop time': '{: >.4}'.format(batch_time.avg),
                                 'Loss': '{: >.4}'.format(losses.avg),
                                 'TOP-1 acc': '{: .5}'.format(top1.avg),
                                 'TOP-5 acc': '{: .5}'.format(top5.avg)
                                 })

    print(' ****************** Acc@1 {top1.avg:.5f} Acc@5 {top5.avg:.5f} Loss {losses.avg:.4f} ******************'.format(top1=top1, top5=top5, losses=losses))

    return top1.avg, top5.avg, losses.avg


def train_one_epoch(cfg, args, model, train_dataloader, optimizer, criterion, lr_scheduler, current_epoch, device,
                    logger=None, tensorboard_writer=None, warmup_epoch=None):

    if tensorboard_writer is not None:
        learning_rate = optimizer.param_groups[0]['lr']
        if warmup_epoch is not None:
            tensorboard_writer.add_scalar("Learning Rate", learning_rate, warmup_epoch)
        else:
            tensorboard_writer.add_scalar("Learning Rate", learning_rate, current_epoch + cfg.TRAIN.WARMUP_EPOCHS)

    batch_time = AverageMeter('Time', ':6.3f')
    data_time = AverageMeter('Data', ':6.3f')
    losses = AverageMeter('Loss', ':.4e')
    top1 = AverageMeter('Acc@1', ':6.2f')
    top5 = AverageMeter('Acc@5', ':6.2f')

    model.train()  # switch model to train mode
    begin_time = time.time()

    train_bar = tqdm(iterable=train_dataloader, desc='Training Process:', file=sys.stdout)

    for i, data in enumerate(train_bar):
        data_time.update(time.time() - begin_time)  # data load time
        learning_rate = optimizer.param_groups[0]['lr']  # got the current LR
        images, labels = data

        if cfg.MODEL.LINK:
            model.link(device)

        images = images.to(device)
        labels = labels.to(device)

        optimizer.zero_grad()
        output = model(images)
        loss = criterion(output, labels)

        loss.backward()
        optimizer.step()
        batch_time.update(time.time() - begin_time)
        begin_time = time.time()

        if warmup_epoch is not None:
            lr_scheduler.step()
            train_bar.set_description(
                'Warmup Process: Epoch[{}] [{}/{}] '.format(warmup_epoch + 1, i + 1, len(train_dataloader)))
        else:
            if cfg.TRAIN.LR_SCHEDULER.TYPE == 'CosineAnnealingLR':
                lr_scheduler.step()
            train_bar.set_description(
                'Training Process: Epoch[{}] [{}/{}] '.format(current_epoch + 1, i + 1, len(train_dataloader)))

        acc1, acc5 = accuracy(output, labels, topk=(1, 5))  # get the top1 and top5 acc during the batch
        losses.update(loss.item(), images.size(0))
        top1.update(acc1[0], images.size(0))  # record the acc to calculate the average parameter
        top5.update(acc5[0], images.size(0))
        train_bar.set_postfix({'Batch prop time: ': '{: >.3}({: >.3})'.format(batch_time.val, batch_time.avg),
                               'Data load time: ': '{: >.3}({: >.3}))'.format(data_time.val, data_time.avg),
                               'LR': '{: >.5}'.format(learning_rate),
                               'Loss: ': '{: >.4}'.format(losses.avg),
                               'TOP-1 acc: ': '{: >.4}'.format(top1.avg),
                               'TOP-5 acc: ': '{: >.4}'.format(top5.avg)
                               })

    if (warmup_epoch is None) & ((cfg.TRAIN.LR_SCHEDULER.TYPE =='StepLR') or (cfg.TRAIN.LR_SCHEDULER.TYPE == 'MultiStepLR')):
        lr_scheduler.step()

    return top1.avg, top5.avg, losses.avg


def do_train(cfg, args, model, train_dataloader, val_dataloader, optimizer, lr_scheduler, warm_up_scheduler, checkpointer, logger, device, tensorboard_writer=None):

    logger.info("{}.trainer".format(cfg.MODEL.ARCHITECTURE))
    logger.info("Start training ...")

    if cfg.TRAIN.LABEL_SMOOTHING > 0:
        criterion = LabelSmoothingCrossEntropy(smoothing=cfg.TRAIN.LABEL_SMOOTHING)
    else:
        criterion = nn.CrossEntropyLoss()

    best_acc = checkpointer.best_acc
    current_epoch = checkpointer.current_epoch

    if cfg.PRE_TRAINED:
        logger.info("Test the performance of the pretrained model ")
        #val_top1_acc, val_top5_acc, val_loss = do_validate(cfg, args, model, val_dataloader, criterion, device)
        #best_acc = max(val_top1_acc, best_acc)

    if cfg.MODEL.PIN_LINK:
        model.weight_pin_link(cfg.MODEL.PIN_LINK_WEIGHT, device)

    # Training warm up
    for warmup_epoch in range(cfg.TRAIN.WARMUP_EPOCHS):
        train_top1_acc, train_top5_acc, train_loss = train_one_epoch(cfg, args, model, train_dataloader, optimizer, criterion, warm_up_scheduler, current_epoch,
                                                                     device, logger, tensorboard_writer,  warmup_epoch=warmup_epoch)
        val_top1_acc, val_top5_acc, val_loss = do_validate(cfg, args, model, val_dataloader, criterion, device)

        logger.info("Training process - Warmup Stage : Epoch[{}] ".format(warmup_epoch))
        logger.info("train_top1_acc:{}, train_top5_acc:{}, train_loss:{}".format(train_top1_acc, train_top5_acc, train_loss))
        logger.info("val_top1_acc:{}, val_top5_acc:{}, val_loss:{}".format(val_top1_acc, val_top5_acc, val_loss))

        checkpointer.current_epoch = current_epoch
        best_flag = val_top1_acc > best_acc
        best_acc = max(val_top1_acc, best_acc)

        if best_flag:
            checkpointer.best_acc = best_acc
            checkpointer.save('checkpoint_best')

        if tensorboard_writer is not None:
            tensorboard_writer.add_scalar('Train_ACC1', train_top1_acc, warmup_epoch)
            tensorboard_writer.add_scalar('Train_Loss', train_loss, warmup_epoch)
            tensorboard_writer.add_scalar('Validate_ACC1', val_top1_acc, warmup_epoch)
            tensorboard_writer.add_scalar('val_loss', train_loss, warmup_epoch)

    for epoch in range(current_epoch, cfg.TRAIN.EPOCHS):
        train_top1_acc, train_top5_acc, train_loss = train_one_epoch(cfg, args, model, train_dataloader, optimizer, criterion, lr_scheduler, epoch,
                                                                     device, logger, tensorboard_writer)
        val_top1_acc, val_top5_acc, val_loss = do_validate(cfg, args, model, val_dataloader, criterion, device)

        logger.info("Training process - Training Stage : Epoch[{}] ".format(epoch))
        logger.info("train_top1_acc:{}, train_top5_acc:{}, train_loss:{}".format(train_top1_acc, train_top5_acc, train_loss))
        logger.info("val_top1_acc:{}, val_top5_acc:{}, val_loss:{}".format(val_top1_acc, val_top5_acc, val_loss))

        checkpointer.current_epoch = current_epoch
        best_flag = val_top1_acc > best_acc
        best_acc = max(val_top1_acc, best_acc)
        if best_flag:
            checkpointer.best_acc = best_acc
            checkpointer.save('checkpoint_best')

        if epoch % cfg.CHECKPOINT_SAVE_FREQ == 0:
            checkpointer.save('checkpoint_train_epoch{}'.format(epoch))

        if tensorboard_writer is not None:
            tensorboard_writer.add_scalar('Train_ACC1', train_top1_acc, epoch+cfg.TRAIN.WARMUP_EPOCHS)
            tensorboard_writer.add_scalar('Train_Loss', train_loss, epoch+cfg.TRAIN.WARMUP_EPOCHS)
            tensorboard_writer.add_scalar('Validate_ACC1', val_top1_acc, epoch+cfg.TRAIN.WARMUP_EPOCHS)
            tensorboard_writer.add_scalar('val_loss', train_loss, epoch+cfg.TRAIN.WARMUP_EPOCHS)

    return model




