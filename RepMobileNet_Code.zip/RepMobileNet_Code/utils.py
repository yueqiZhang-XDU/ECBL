import torch
import logging
import os
import sys
sys.path.append('../')
from torchvision import transforms, datasets
from torch.optim.lr_scheduler import _LRScheduler
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR, LinearLR, StepLR, MultiStepLR
from torch.nn.parallel import DistributedDataParallel
from model.utils import load_mbv2_pretrained_weight

def setup_logger(name, distributed_rank, save_dir=None):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    # don't log results for the non-master process
    if distributed_rank > 0:
        return logger
    stream_handler = logging.StreamHandler(stream=sys.stdout)
    stream_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(asctime)s %(name)s %(levelname)s: %(message)s")
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    if save_dir:
        fh = logging.FileHandler(os.path.join(save_dir, 'log.txt'))
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(formatter)
        logger.addHandler(fh)
    return logger


class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self, name, fmt=':f'):
        self.name = name
        self.fmt = fmt
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

    def __str__(self):
        fmtstr = '{name} {val' + self.fmt + '} ({avg' + self.fmt + '})'
        return fmtstr.format(**self.__dict__)


def accuracy(output, target, topk=(1,)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = output.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res


class WarmUpLR(_LRScheduler):
    def __init__(self, optimizer, total_tiers, last_epoch=-1):
        self.total_tiers = total_tiers
        super(WarmUpLR, self).__init__(optimizer, last_epoch)

    def get_lr(self):
        return [base_lr * self.last_epoch / (self.total_tiers + 1e-8) for base_lr in self.base_lrs]


class CheckPointer(object):
    _last_checkpoint_name = 'last_checkpoint.txt'
    def __init__(self,
                 model,
                 optimizer=None,
                 scheduler=None,
                 save_dir="",
                 save_to_disk=None,
                 logger=None):
        self.model = model
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.save_dir = save_dir
        self.save_to_disk = save_to_disk
        self.current_epoch = 0
        self.best_acc = 0
        if logger is None:
            logger = logging.getLogger(__name__)
        self.logger = logger

    def save(self, name, **kwargs):
        if not self.save_dir:
            return

        if not self.save_to_disk:
            return

        data = {}
        if isinstance(self.model, DistributedDataParallel):
            data['model'] = self.model.module.state_dict()
        else:
            data['model'] = self.model.state_dict()
        if self.optimizer is not None:
            data["optimizer"] = self.optimizer.state_dict()
        if self.scheduler is not None:
            data["scheduler"] = self.scheduler.state_dict()
        data.update(kwargs)

        data['current_epoch'] = self.current_epoch
        data['best_acc'] = self.best_acc

        save_file = os.path.join(self.save_dir, "{}.pth".format(name))
        self.logger.info("Saving checkpoint to {}".format(save_file))
        torch.save(data, save_file)

        self.tag_last_checkpoint(save_file)

    def load(self, f=None, use_latest=True, test_flag=None):
        if self.has_checkpoint() and use_latest:
            # override argument with existing checkpoint
            f = self.get_checkpoint_file()
        if not f:
            # no checkpoint could be found
            self.logger.info("No checkpoint found.")
            return {}

        self.logger.info("Loading checkpoint from {}".format(f))
        checkpoint = self._load_file(f)
        model = self.model
        if isinstance(model, DistributedDataParallel):
            model = self.model.module

        model.load_state_dict(checkpoint.pop("model"))
        if test_flag is None:
            if "optimizer" in checkpoint and self.optimizer:
                self.logger.info("Loading optimizer from {}".format(f))
                self.optimizer.load_state_dict(checkpoint.pop("optimizer"))
            if "scheduler" in checkpoint and self.scheduler:
                self.logger.info("Loading scheduler from {}".format(f))
                self.scheduler.load_state_dict(checkpoint.pop("scheduler"))

            if "current_epoch" in checkpoint and self.scheduler:
                self.logger.info("Loading scheduler from {}".format(f))
                self.current_epoch = checkpoint['current_epoch']

            if "best_acc" in checkpoint and self.scheduler:
                self.best_acc = checkpoint['best_acc']

        # return any further checkpoint data
        return checkpoint

    def get_checkpoint_file(self):
        save_file = os.path.join(self.save_dir, self._last_checkpoint_name)
        try:
            with open(save_file, "r") as f:
                last_saved = f.read()
                last_saved = last_saved.strip()
        except IOError:
            # if file doesn't exist, maybe because it has just been
            # deleted by a separate process
            last_saved = ""
        return last_saved

    def has_checkpoint(self):
        save_file = os.path.join(self.save_dir, self._last_checkpoint_name)
        return os.path.exists(save_file)

    def tag_last_checkpoint(self, last_filename):
        save_file = os.path.join(self.save_dir, self._last_checkpoint_name)
        with open(save_file, "w") as f:
            f.write(last_filename)

    def _load_file(self, f):
        # download url files
        return torch.load(f, map_location=torch.device("cpu"))

def build_datatransform(args):
    data_transform = {
        "train": transforms.Compose([transforms.RandomResizedCrop(224),
                                     transforms.RandomHorizontalFlip(),
                                     transforms.ToTensor(),
                                     transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])]),
        "val": transforms.Compose([transforms.Resize(256),
                                   transforms.CenterCrop(224),
                                   transforms.ToTensor(),
                                   transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])}   #transforms.ToTensor(),transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    train_dataset = datasets.ImageFolder(root=os.path.join(args.dataset_root, "train"), transform=data_transform["train"])
    val_dataset = datasets.ImageFolder(root=os.path.join(args.dataset_root, "val"), transform=data_transform["val"])
    print('The number of Train Image: {}, Validate Image: {}'.format(len(train_dataset), len(val_dataset)))
    return {'train': train_dataset, 'val': val_dataset}


def bulid_dataloader(dataset, cfg):
    train_loader = torch.utils.data.DataLoader(dataset['train'], batch_size=cfg.DATA.BATCH_SIZE,
                                               shuffle=True, num_workers=cfg.DATA.NUM_WORKERS, pin_memory=cfg.DATA.PIN_MEMORY)
    val_loader = torch.utils.data.DataLoader(dataset['val'],  batch_size=cfg.DATA.BATCH_SIZE,
                                             shuffle=False, num_workers=cfg.DATA.NUM_WORKERS, pin_memory=cfg.DATA.PIN_MEMORY)
    return train_loader, val_loader


def build_optimizer(model, cfg):
    if cfg.TRAIN.OPTIMIZER.NAME == 'adam':
        return optim.Adam(model.parameters(), lr=cfg.TRAIN.LR, weight_decay=cfg.TRAIN.WEIGHT_DECAY)   # Adam 动量是自动的
    elif cfg.TRAIN.OPTIMIZER.NAME == 'sgd':
        parameters = set_weight_decay(model)
        return optim.SGD(parameters, lr=cfg.TRAIN.LR, momentum=cfg.TRAIN.OPTIMIZER.MOMENTUM, weight_decay=cfg.TRAIN.WEIGHT_DECAY)
    else:
        raise NotImplementedError("We only support Adam and SGD optimizer now.")


def build_lr_scheduler(optimizer, cfg, iter_per_epoch):
    if cfg.TRAIN.LR_SCHEDULER.TYPE == 'CosineAnnealingLR':
        lr_scheduler = CosineAnnealingLR(optimizer=optimizer, T_max=cfg.TRAIN.EPOCHS * iter_per_epoch)
    elif cfg.TRAIN.LR_SCHEDULER.TYPE == 'StepLR':
        lr_scheduler = StepLR(optimizer=optimizer, step_size=cfg.TRAIN.LR_SCHEDULER.STEP_SIZE, gamma=cfg.TRAIN.LR_SCHEDULER.Gamma)
    elif cfg.TRAIN.LR_SCHEDULER.TYPE == 'MultiStepLR':
        lr_scheduler = MultiStepLR(optimizer=optimizer, milestones=cfg.TRAIN.LR_SCHEDULER.MILESTONES, gamma=cfg.TRAIN.LR_SCHEDULER.Gamma)
    else:
        raise NotImplementedError("We only support CosineAnnealingLR, StepLR and MultiStepLR optimizer now.")

    return lr_scheduler

def build_warm_up_scheduler(optimizer, cfg, iter_per_epoch):
    warmup_scheduler = WarmUpLR(optimizer=optimizer, total_tiers=cfg.TRAIN.WARMUP_EPOCHS * iter_per_epoch)
    return warmup_scheduler


def load_pre_trained_weight(model, cfg, pre_trained_weight_dir):

    if cfg.PRE_TRAINED_WEIGHT_TYPE == 'mbv2_pre_trained':
        load_mbv2_pretrained_weight(model, weight_dir=pre_trained_weight_dir)
    elif cfg.PRE_TRAINED_WEIGHT_TYPE == 'RepMobileNet_pre_trained':
        pre_trained_weight = torch.load(pre_trained_weight_dir, map_location='cpu')
        model.load_state_dict(pre_trained_weight)


#  设置weight decay 作为调参方法
def set_weight_decay(model, skip_list=(), skip_keywords=(), echo=False):
    has_decay = []
    no_decay = []

    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue  # frozen weights
        if 'identity.weight' in name:
            has_decay.append(param)
            if echo:
                print(f"{name} USE weight decay")
        elif len(param.shape) == 1 or name.endswith(".bias") or (name in skip_list) or \
            check_keywords_in_name(name, skip_keywords):
            no_decay.append(param)
            if echo:
                print(f"{name} has no weight decay")
        else:
            has_decay.append(param)
            if echo:
                print(f"{name} USE weight decay")

    return [{'params': has_decay},
            {'params': no_decay, 'weight_decay': 0.}]


def check_keywords_in_name(name, keywords=()):
    isin = False
    for keyword in keywords:
        if keyword in name:
            isin = True
    return isin

