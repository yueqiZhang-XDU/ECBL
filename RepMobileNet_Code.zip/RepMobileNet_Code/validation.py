import os
import logging
import random
import argparse
import torch
import numpy as np
import torch.nn as nn
from default_config import _C as cfg
from model.repmobilenet_a import Repmobilenet_A
from model.repmobilenet_b import Repmobilenet_B
from utils import build_datatransform, bulid_dataloader, CheckPointer
from do_function import do_validate
from timm.loss import LabelSmoothingCrossEntropy
from torchsummary import summary
from torchstat import stat


def test(cfg, args):

    if cfg.MODEL.ARCHITECTURE == 'A':
        print('constructing RepMobileNet-A')
        model = Repmobilenet_A(input_size=cfg.DATA.IMG_SIZE, channel_multi=cfg.MODEL.ALPHA, num_class=cfg.MODEL.NUM_CLASSES, nolinear_type=cfg.MODEL.NO_LINEAR, block_setting=cfg.MODEL.BLOCK_SETTING)
    elif cfg.MODEL.ARCHITECTURE == 'B':
        print('constructing RepMobileNet-B')
        model = Repmobilenet_B(input_size=cfg.DATA.IMG_SIZE, num_class=cfg.MODEL.NUM_CLASSES, input_channel_multi=cfg.MODEL.ALPHA, block_setting=cfg.MODEL.BLOCK_SETTING)
    else:
        raise NotImplementedError("We only support RepMobileNet A and B structure Now")

    if cfg.SEEDS is not None:
        random.seed(cfg.SEEDS)
        torch.manual_seed(cfg.SEEDS)
        np.random.seed(cfg.SEEDS)
        torch.cuda.manual_seed(cfg.SEEDS)

    # Load Datasets
    datasets = build_datatransform(args)
    train_dataloader, val_dataloader = bulid_dataloader(datasets, cfg)
    if cfg.TRAIN.LABEL_SMOOTHING > 0:
        criterion = LabelSmoothingCrossEntropy(smoothing=cfg.TRAIN.LABEL_SMOOTHING)
    else:
        criterion = nn.CrossEntropyLoss()

    device = torch.device(cfg.DEVICE) if torch.cuda.is_available() else 'cpu'
    model.to(device)

    checkpointer = CheckPointer(model, None, None, os.path.dirname(__file__), True, None)  # container of the load checkpoint
    if args.checkpoint_dir is not None:
        print('Load the checkpoint')
        # checkpoint_dir = os.path.join(args.checkpoint_dir)
        checkpointer.load(f=args.checkpoint_dir, use_latest=False)
    else:
        raise NotImplementedError("The load checkpoint file is not exist")

    # val_top1_acc, val_top5_acc, val_loss = do_validate(cfg, args, model, val_dataloader, criterion, device)

    # test the merged single-branch network
    model.cpu()
    model.convert_to_single_branch()
    model.to(device)
    val_top1_acc, val_top5_acc, val_loss = do_validate(cfg, args, model, val_dataloader, criterion, device)


def main():

    parser = argparse.ArgumentParser(description='Train RepMobileNet for ImageNet Classification With Pytorch')
    parser.add_argument('--dataset_root', type=str, help='Set the Absolute Path of the Dataset')
    parser.add_argument('--config_file', type=str, help='Set the Relative Path of the config file')
    parser.add_argument('--checkpoint_dir', type=str, default=None, help='Set the Relative Path of checkpoint and test the performance of network')

    args = parser.parse_args()

    num_gpus = int(os.environ["WORLD_SIZE"]) if "WORLD_SIZE" in os.environ else 1
    args.distribute_train = num_gpus > 1
    args.num_gpus = num_gpus if torch.cuda.is_available() else 1
    args.device = cfg.DEVICE if torch.cuda.is_available() else 1

    cfg.merge_from_file(args.config_file)
    cfg.freeze()

    test(cfg, args)


if __name__ == '__main__':
    main()

